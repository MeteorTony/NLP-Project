m1=mas
m2=vicuna-13b
eval_model=gpt-35-turbo
bpc=1
k=3
python3 FairEval/FairEval.py \
    -q FairEval/question.jsonl \
    -a FairEval/answer/answer_$m1.jsonl FairEval/answer/answer_$m2.jsonl \
    -o FairEval/review/review_${m1}_${m2}_${eval_model}_mec${k}_bpc${bpc}.json \
    -m $eval_model \
    --bpc $bpc \
    -k $k